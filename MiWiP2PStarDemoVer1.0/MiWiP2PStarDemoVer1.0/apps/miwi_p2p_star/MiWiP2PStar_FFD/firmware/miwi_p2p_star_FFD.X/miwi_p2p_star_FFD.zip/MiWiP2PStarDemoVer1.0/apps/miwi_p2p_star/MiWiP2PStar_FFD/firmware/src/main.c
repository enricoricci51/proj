/********************************************************************
 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the "Company") for its PIC(R) Microcontroller is intended and
 supplied to you, the Company's customer, for use solely and
 exclusively on Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *******************************************************************/

/************************ HEADERS ****************************************/
#include "task.h"


/*********************************************************************
* Function:         void main(void)
*
* PreCondition:     none
*
* Input:		    none
*
* Output:		    none
*
* Side Effects:	    none
*
* Overview:		    This is the main function that runs the simple 
*                   example demo. The purpose of this example is to
*                   demonstrate the simple application programming
*                   interface for the MiWi(TM) Development 
*                   Environment. By virtually total of less than 30 
*                   lines of code, we can develop a complete 
*                   application using MiApp interface. The 
*                   application will first try to establish a
*                   link with another device and then process the 
*                   received information as well as transmit its own 
*                   information.
*                   MiWi(TM) DE also support a set of rich 
*                   features. Example code FeatureExample will
*                   demonstrate how to implement the rich features 
*                   through MiApp programming interfaces.
*
* Note:			    
**********************************************************************/
MAIN_RETURN main ( void )
{   
    bool freezer_enable = false;  // if true will save the ntrwk details in EEPROM 
    
    /*********************************************************************
    * void hardware_init( void )
    *
    * Overview:        This function initializes the Hardware for demo
    *                  
    *
    * PreCondition:    None
    *
    * Input:           None
    *
    * Output:          None 
    * 
    ********************************************************************/  
    hardware_init();
    
    #if defined(ENABLE_NETWORK_FREEZER)
    /*********************************************************************
     * bool freezer_feature( void )
     *
     * Overview:        This function prompts the user to opt a New Network option
     *                   or to restore the old network stored in EEPROM
     *
     * PreCondition:    enable network freezer in miwi_config.h , hardware_init()
     *
     * Input:           None
     *
     * Output:          boolean true or false
     *
     * Side Effects:   None 
     * 
     ********************************************************************/
        freezer_enable = freezer_feature();
    #endif
    
    /*********************************************************************
    * void Initialize_Demo( bool )
    *
    * Overview:          On selection of a new network option , this function will 
     *                          initialize the miwi network , radio, set the parameters 
    *                           like channel , connection mode , create / join a network.
     *                          On selection of restore option , this function will just read  
     *                          the network details stored in EEPROM and restore the network
    * PreCondition:    hardware_init() 
    *
    * Input:           bool --> denoting new network or restore network option
    *
    * Output:          None
    *
    * Side Effects:    None 
    * 
    ********************************************************************/
     Initialize_Demo(freezer_enable);

    while(1)
    {
         /*********************************************************************
        * void Run_Demo( void )
        *
        * Overview:          This function will demonstrate the demo , based on protocol
        *                         choosen in miwi_config.h  , p2p or star
        * 
        * PreCondition:    hardware_init() , Initialize_Demo() 
        *
        * Input:           None
        *
        * Output:          None
        *
        * Side Effects:    None 
        * 
        ********************************************************************/
        Run_Demo();
    }

    #if defined(__XC8__)
        return;
    #else
        return 0;
    #endif
}


